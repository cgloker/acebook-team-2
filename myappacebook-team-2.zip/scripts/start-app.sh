#!/bin/bash
cd /Users/cintiagloker/devops/projects/acebook-team-2

echo "The ApplicationStart deployment lifecycle event successfully completed." > application-start.txt