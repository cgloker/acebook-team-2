#!/bin/bash
cd ~/aws-codedeploy
pm2 startOrReload ecosystem.config.js 